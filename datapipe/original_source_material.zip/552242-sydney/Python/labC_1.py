# pip install --user --upgrade pandas, pandas_datareader, scipy, matplotlib, pyodbc, pycountry, azure
# This is a line comment
'''
This is a block comment.
It ignores information between the three (3) single quotes
'''
import numpy
import matplotlib, pandas as pd
help
help(numpy)
dir(matplotlib)
print("Data Science is better than chocolate.")
input1 = input("Please enter a number between 10 and 20: ")

sequence1 = (10,20,30,40,50,60,70,80,90,100) ; list1 = list(sequence1)
len(sequence1)
print(sorted(list1,reverse=True))
string1 = "0000000Please remove the zeros from this string.0000000" ; print(string1.strip('0'))
dict1 = {'name':'Carlos Santiago','age':'43','phone':'123-456-789'} ; type(dict1) ; dict1.keys() ; dict1.values()

